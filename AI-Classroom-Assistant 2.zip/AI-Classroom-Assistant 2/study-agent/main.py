from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class StudyRequest(BaseModel):
    topic: str
    days_until_exam: int = 7


@app.post("/study_plan")
def study_plan(request: StudyRequest):

    print("[STUDY AGENT] Creating plan for:", request.topic)

    plan = [
        f"Day 1-2: Basics of {request.topic}",
        f"Day 3-4: Practice problems",
        f"Day 5: Quiz yourself",
        f"Day 6: Review mistakes",
        f"Day 7: Final review"
    ]

    print("[STUDY AGENT] Plan ready")

    return {
        "topic": request.topic,
        "plan": plan
    }