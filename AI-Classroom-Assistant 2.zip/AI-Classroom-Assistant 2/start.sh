#!/bin/bash

echo "Starting AI Classroom Assistant..."

# Activate virtual environment
source venv/bin/activate

# Start FAQ Agent
echo "Starting FAQ Agent on port 8000..."
uvicorn faq-agent.main:app --reload --port 8000 &
FAQ_PID=$!

# Start Assessment Agent
echo "Starting Assessment Agent on port 8002..."
uvicorn assessment-agent.main:app --reload --port 8002 &
ASSESSMENT_PID=$!

# Start Study Agent
echo "Starting Study Agent on port 8003..."
uvicorn study-agent.main:app --reload --port 8003 &
STUDY_PID=$!

# Start Orchestrator
echo "Starting Orchestrator on port 8001..."
uvicorn orchestrator.main:app --reload --port 8001 &
ORCH_PID=$!

echo "All services started!"
echo "Press CTRL+C to stop all services"

# Wait for user interrupt
wait $FAQ_PID $ASSESSMENT_PID $STUDY_PID $ORCH_PID
