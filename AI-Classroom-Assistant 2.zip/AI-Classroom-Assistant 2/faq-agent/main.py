import json
from pathlib import Path

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

DOCS_DIR = Path(__file__).resolve().parent.parent / "docs"
FALLBACK_ANSWER = (
    "I don't have an answer for that question yet. "
    "Try asking about Newton's laws, gravity, energy, velocity, or acceleration."
)


class FAQRequest(BaseModel):
    question: str


def load_faq_entries() -> list[dict]:
    entries = []
    if not DOCS_DIR.exists():
        return entries

    for file_path in sorted(DOCS_DIR.glob("*.json")):
        with file_path.open(encoding="utf-8") as file:
            data = json.load(file)
            if isinstance(data, list):
                entries.extend(data)

    return entries


def find_answer(question: str, entries: list[dict]) -> str:
    normalized_question = question.lower()
    best_match = None
    best_score = 0

    for entry in entries:
        score = 0
        for keyword in entry.get("keywords", []):
            if keyword.lower() in normalized_question:
                score += len(keyword)

        if score > best_score:
            best_score = score
            best_match = entry

    if best_match:
        return best_match["answer"]

    return FALLBACK_ANSWER


FAQ_ENTRIES = load_faq_entries()


@app.post("/faq")
def faq(request: FAQRequest):
    print("[FAQ AGENT] Received question:", request.question)

    answer = find_answer(request.question, FAQ_ENTRIES)

    print("[FAQ AGENT] Sending response")

    return {
        "answer": answer
    }
